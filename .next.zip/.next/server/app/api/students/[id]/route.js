var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/students/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0ao1o84._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__0.djhtq._.js")
R.c("server/chunks/_next-internal_server_app_api_students_[id]_route_actions_0z4lvpq.js")
R.m(85144)
module.exports=R.m(85144).exports
