:HL["/_next/static/chunks/0o2aj~zkel6s1.css","style"]
:HL["https://cdn.jsdelivr.net/npm/remixicon/fonts/remixicon.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"OuWlbKF_Zlmq2p2qh9NCY"}
