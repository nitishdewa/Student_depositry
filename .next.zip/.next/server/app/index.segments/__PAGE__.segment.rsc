1:"$Sreact.fragment"
2:I[91958,["/_next/static/chunks/0dbhjjzl8qfwv.js","/_next/static/chunks/100r-.8_xy7fr.js"],"default"]
3:I[97367,["/_next/static/chunks/0dbhjjzl8qfwv.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/100r-.8_xy7fr.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"OuWlbKF_Zlmq2p2qh9NCY"}
5:null
